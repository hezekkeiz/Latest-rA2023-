#ifndef C4_YML_STD_STRING_HPP_
#define C4_YML_STD_STRING_HPP_

/** @file string.hpp substring conversions for/from std::string */

// everything we need is implemented here:
#include <c4/std/string.hpp>

#endif // C4_YML_STD_STRING_HPP_
